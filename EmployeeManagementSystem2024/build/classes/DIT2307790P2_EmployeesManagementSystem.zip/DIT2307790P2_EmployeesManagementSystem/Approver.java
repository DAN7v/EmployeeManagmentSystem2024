/*
NAME: Dan Abdulaziz Alghamdi
ID NUMBER:2307790
SECTION: DIT
COURSE: CPCS203
Instructor: LAB: Nuha alnahdi. Helen bakash.
 */
package Assign2;

import java.time.LocalDate;

public interface Approver {

    public abstract void approveLeave(Employee e, LocalDate d, int f);

    public abstract void markEmployeeAsWorking(Employee e);
}
