/*
NAME: Dan Abdulaziz Alghamdi
ID NUMBER:2307790
SECTION: DIT
COURSE: CPCS203
Instructor: LAB: Nuha alnahdi. Helen bakash.
 */
package Assign2;


public class Designer extends Employee {

    public Designer(String name, int id, double salary) {
        super(name, id, salary);
    }

    @Override
    public double calculateBonus() {

        return (super.getSalary() * .1);
    }

}

